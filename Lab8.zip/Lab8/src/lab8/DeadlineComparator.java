package lab8;

import java.util.Comparator;

public class DeadlineComparator implements Comparator<Task> {

	public int compare(Task x, Task y) {
		return 0;
	}
}
