package lab8;

import java.util.Comparator;

public class LengthComparator implements Comparator<Task> {

	public int compare(Task x, Task y) {
		return 0;
	}
}
