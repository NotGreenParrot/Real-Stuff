/**
 * TODO - add some comments here.
 *
 * @author Benjamin Kuperman (Spring 2011), Cynthia Taylor (Summer 2021)
 * @author YOU!
 */
package lab8;

import java.util.AbstractQueue;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;

public class MyPriorityQueue<T> extends AbstractQueue<T> {

    /** Item to use for making comparisons */
    private Comparator<T> cmp;

    /** ArrayList for the heap itself */
    private ArrayList<T> heap;


     /* Constructor */
    public MyPriorityQueue(int initial_capacity, Comparator<T> cmp) {

    }
    
    public MyPriorityQueue(Comparator<T> cmp) {

    }
    
    /**
     * Index of the parent of a node 
     */
    private int parent(int index) {

    }

    /**
     * Index of the left child of a node
     */
    private int lchild(int index) {

    }

    /**
     *  Index of the right child of a node
     */
    private int rchild(int index) {

    }
 
    public Comparator<T> comparator() {
    	return cmp;
    }

    public Iterator<T> iterator() {
    	return heap.iterator();
    }

    public int size() {

    }

    public void clear() {

    }

    public boolean offer(T elt) {

    }

    public T peek() {

    }

    public T poll() {

    }
 
    private void percolateDown(int hole) {

    }

    private void percolateUp(int hole) {

    }

 

}
